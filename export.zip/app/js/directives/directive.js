appDirectives.directive('tplMyData', function() {
	return {
		restrict: 'E',
		templateUrl: 'partials/directives/tpl.my.data.html'
	};
});